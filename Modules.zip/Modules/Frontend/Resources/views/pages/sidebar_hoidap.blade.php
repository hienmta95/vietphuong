<div class="qa" style="background: url({{ cxl_asset($info['logoImage']['url']) }}) center center no-repeat;">

    <h1>Hỏi đáp</h1>
    <p>
        <span class="quote1">" Nếu có bất cứ thắc mắc nào liên quan, </span>
        <span class="quote2">xin hãy đặt câu hỏi cho chúng tôi  "</span>
    </p>
    <p>Hotline: {{ $info['sdtcongty'] }}</p>
    <a href="{{ route('lienhe') }}" class="btn btn-green">Hỏi đáp</a>
</div>
